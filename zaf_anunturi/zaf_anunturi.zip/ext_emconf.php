<?php

########################################################################
# Extension Manager/Repository config file for ext "zaf_anunturi".
#
# Auto generated 25-07-2012 12:24
#
# Manual updates:
# Only the data in the array - everything else is removed by next
# writing. "version" and "dependencies" must not be touched!
########################################################################

$EM_CONF[$_EXTKEY] = array(
	'title' => 'ZAF Anunturi',
	'description' => '',
	'category' => 'plugin',
	'author' => 'Cristi',
	'author_email' => 'bau_baus2002@yahoo.com',
	'shy' => '',
	'dependencies' => '',
	'conflicts' => '',
	'priority' => '',
	'module' => '',
	'state' => 'stable',
	'internal' => '',
	'uploadfolder' => 1,
	'createDirs' => 'uploads/tx_zafanunturi',
	'modify_tables' => '',
	'clearCacheOnLoad' => 0,
	'lockType' => '',
	'author_company' => '',
	'version' => '0.0.0',
	'constraints' => array(
		'depends' => array(
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
	'_md5_values_when_last_written' => 'a:15:{s:9:"ChangeLog";s:4:"dcd3";s:10:"README.txt";s:4:"ee2d";s:12:"ext_icon.gif";s:4:"1bdc";s:17:"ext_localconf.php";s:4:"2677";s:14:"ext_tables.php";s:4:"c4d0";s:14:"ext_tables.sql";s:4:"da8f";s:31:"icon_tx_zafanunturi_anunuri.gif";s:4:"475a";s:16:"locallang_db.xml";s:4:"8918";s:7:"tca.php";s:4:"00a4";s:19:"doc/wizard_form.dat";s:4:"ddd3";s:20:"doc/wizard_form.html";s:4:"cdca";s:32:"pi1/class.tx_zafanunturi_pi1.php";s:4:"3946";s:17:"pi1/locallang.xml";s:4:"7129";s:32:"pi2/class.tx_zafanunturi_pi2.php";s:4:"2fda";s:17:"pi2/locallang.xml";s:4:"11ea";}',
);

?>